# HackRF  Android App
 Downloaded from https://github.com/demantz/hackrf_android , modified the UI and compiled with the latest version of Android Studio targeting SdkVersion 30.
 Thank you Dennis Mantz
 
Here are two methods for using this software.

1. Download the full Android Studio Project and build your own apk from MyHackRF.zip
2. Or Download the app-debug.apk to your Android and tap to install.
